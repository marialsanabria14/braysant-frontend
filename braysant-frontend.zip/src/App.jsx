import React from 'react';
function App() { return <div>App BRAYSANT funcionando</div>; }
export default App;