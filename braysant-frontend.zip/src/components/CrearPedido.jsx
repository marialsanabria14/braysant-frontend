import React, { useState, useEffect } from 'react';
import axios from '../axiosConfig';

function CrearPedido() {
  const [centros, setCentros] = useState([]);
  const [productos, setProductos] = useState([]);
  const [pedido, setPedido] = useState({ centro_costo_id: '', productos: [], comentarios: '' });
  const [productoSeleccionado, setProductoSeleccionado] = useState('');
  const [cantidad, setCantidad] = useState(1);

  useEffect(() => {
    fetchCentros();
    fetchProductos();
  }, []);

  const fetchCentros = async () => {
    const res = await axios.get('/centros-costos');
    setCentros(res.data);
  };

  const fetchProductos = async () => {
    const res = await axios.get('/productos');
    setProductos(res.data);
  };

  const agregarProducto = () => {
    const prod = productos.find((p) => p.id === parseInt(productoSeleccionado));
    const subtotal = cantidad * prod.precio_unitario;

    setPedido({
      ...pedido,
      productos: [...pedido.productos, {
        producto_id: prod.id,
        nombre: prod.nombre,
        cantidad,
        subtotal
      }]
    });
    setProductoSeleccionado('');
    setCantidad(1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      centro_costo_id: parseInt(pedido.centro_costo_id),
      productos: pedido.productos.map(p => ({
        producto_id: p.producto_id,
        cantidad: p.cantidad,
        subtotal: p.subtotal
      })),
      comentarios: pedido.comentarios
    };
    await axios.post('/pedidos', payload);
    alert('Pedido creado exitosamente');
    setPedido({ centro_costo_id: '', productos: [], comentarios: '' });
  };

  return (
    <div>
      <h2 className="text-xl font-semibold mb-2">Crear Pedido</h2>
      <form onSubmit={handleSubmit} className="mb-4">
        <div className="mb-2">
          <label>Centro de Costo:</label>
          <select name="centro_costo_id" value={pedido.centro_costo_id} onChange={(e) => setPedido({ ...pedido, centro_costo_id: e.target.value })} className="border p-2 ml-2">
            <option value="">Seleccione</option>
            {centros.map((c) => (
              <option key={c.id} value={c.id}>{c.nombre}</option>
            ))}
          </select>
        </div>

        <div className="mb-2">
          <label>Producto:</label>
          <select value={productoSeleccionado} onChange={(e) => setProductoSeleccionado(e.target.value)} className="border p-2 ml-2">
            <option value="">Seleccione</option>
            {productos.map((p) => (
              <option key={p.id} value={p.id}>{p.nombre} (${p.precio_unitario.toFixed(2)})</option>
            ))}
          </select>
          <input type="number" min="1" value={cantidad} onChange={(e) => setCantidad(parseInt(e.target.value))} className="border p-2 ml-2 w-20" />
          <button type="button" onClick={agregarProducto} className="bg-blue-500 text-white p-2 rounded ml-2">Agregar</button>
        </div>

        <div className="mb-2">
          <label>Comentarios:</label>
          <textarea value={pedido.comentarios} onChange={(e) => setPedido({ ...pedido, comentarios: e.target.value })} className="border p-2 w-full" />
        </div>

        <button type="submit" className="bg-green-500 text-white p-2 rounded">Enviar Pedido</button>
      </form>

      <h3 className="font-semibold">Detalle del Pedido:</h3>
      <table className="table-auto w-full">
        <thead>
          <tr>
            <th className="border p-2">Producto</th>
            <th className="border p-2">Cantidad</th>
            <th className="border p-2">Subtotal</th>
          </tr>
        </thead>
        <tbody>
          {pedido.productos.map((p, index) => (
            <tr key={index}>
              <td className="border p-2">{p.nombre}</td>
              <td className="border p-2">{p.cantidad}</td>
              <td className="border p-2">${p.subtotal.toFixed(2)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default CrearPedido;
